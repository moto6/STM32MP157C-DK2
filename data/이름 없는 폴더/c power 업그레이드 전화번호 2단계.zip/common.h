/* Name: common.h  ver 1.0
 * Content: ���� ANSI ǥ�� ���.
 * Implementation: YSW
 * 
 * Last modified 2008/01/01
 */

#ifndef __COMMOM_H__
#define __COMMON_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#endif

/* end of file */